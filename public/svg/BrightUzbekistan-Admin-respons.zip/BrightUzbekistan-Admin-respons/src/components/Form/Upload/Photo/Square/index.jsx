import { useState } from 'react';
import Flex from '../../../../Flex';
import Button from '../../Button';
import cls from './Square.module.scss'

const SquarePhotoUpload = ({ register, setValue = () => {}, name = '' }) => {
    const [selectedfile, setSelectedFile] = useState({})

    const handleChange = (e) => {
        const file = e.target.files[0]
        if (file) {
            setValue(name, file)
            setSelectedFile({ name: file.name, img: file })
        } else {
            setValue(name, null)
        }
    }

    return (
        <Flex gap='10' direction='column'>
            <label style={{ cursor: 'pointer' }}>
                <span className={cls.text}>Фото к зоголовку</span>
                <div className={cls.box}>
                    <div className={cls.box__preview} onDoubleClick={() => {setSelectedFile({}); setValue(name, null)}}>
                        {
                            !selectedfile?.img ? (
                                <span>Нет фото</span>
                            ) : (
                                <img src={URL.createObjectURL(selectedfile.img)} alt={selectedfile?.name || ''} />
                            )
                        }
                    </div>
                    <label>
                        {!selectedfile?.img && <input type="file" accept='image/png, image/jpeg, image/jpg' className={cls.input} {...register} onChange={handleChange} />}
                        <Button />
                        <Flex direction='column' gap='2'>
                            <p className={cls.box__title}>Загрузить фото</p>
                            <span className={cls.box__name}>{selectedfile.name}</span>
                        </Flex>
                    </label>
                </div>
            </label>
        </Flex>
    );
}

export default SquarePhotoUpload;
