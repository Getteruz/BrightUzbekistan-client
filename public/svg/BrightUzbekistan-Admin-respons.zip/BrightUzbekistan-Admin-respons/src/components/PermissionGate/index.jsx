import { permissions } from "./data";

const PermissionGate = ({
    children,
    allowedPermissions = []
}) => {
    return (
        <div>
            
        </div>
    );
}

export default PermissionGate;
