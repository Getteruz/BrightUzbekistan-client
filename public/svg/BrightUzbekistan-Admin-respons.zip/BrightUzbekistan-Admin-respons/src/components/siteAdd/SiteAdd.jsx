import React from 'react'
import cls from './SiteAdd.module.scss'

export default function SiteAdd() {
    return (
        <div className={cls.SiteAdd}>
        </div>
    )
}
