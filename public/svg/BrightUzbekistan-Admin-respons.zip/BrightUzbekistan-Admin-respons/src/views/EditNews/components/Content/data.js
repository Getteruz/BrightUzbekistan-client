export const langs = [
    {id: 0, lang: 'uz', label: "O‘zbekcha"},
    {id: 1, lang: 'уз', label: "Ўзбекча"},
    {id: 2, lang: 'ru', label: "Русский"},
    {id: 3, lang: 'en', label: "English"},
]