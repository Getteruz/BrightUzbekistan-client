export const btns = [
    {
        id: 0,
        label: 'Опубликованные',
        link: 'published'
    },
    {
        id: 1,
        label: 'Избранные',
        link: 'favorites'
    },
    {
        id: 2,
        label: 'Даработке',
        link: 'general access'
    },
    {
        id: 3,
        label: 'Отказона',
        link: 'refected'
    },
    {
        id: 4,
        label: 'Архивы',
        link: 'archive'
    },
]