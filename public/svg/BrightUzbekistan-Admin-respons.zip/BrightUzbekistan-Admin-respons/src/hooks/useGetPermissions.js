export const useGetPermissions = () => {
    
}